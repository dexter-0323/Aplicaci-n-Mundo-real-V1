﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Aerolinea.Models;

namespace Aerolinea.Controllers
{
    public class VueloController : Controller
    {
        private AeroliniaEntities db = new AeroliniaEntities();

        public ActionResult Index()
        {
            var vuelos = db.Vuelos.Include(v => v.Avione).Include(v => v.Empleado);
            return View(vuelos.ToList());
        }

        public ActionResult Agregar()
        {
            ViewBag.Avion = new SelectList(db.Aviones, "Modelo", "Modelo");
            ViewBag.Piloto = new SelectList(db.Empleados, "Nombre", "Apellido");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Agregar([Bind(Include = "Piloto,Avion,Cantidad_Pasajeros")] Vuelo vuelo)
        {
            if (ModelState.IsValid)
            {
                db.Vuelos.Add(vuelo);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Avion = new SelectList(db.Aviones, "Modelo", "Modelo", vuelo.Avion);
            ViewBag.Piloto = new SelectList(db.Empleados, "Nombre", "Apellido", vuelo.Piloto);
            return View(vuelo);
        }

        public ActionResult Editar(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Vuelo vuelo = db.Vuelos.Find(id);
            if (vuelo == null)
            {
                return HttpNotFound();
            }
            ViewBag.Avion = new SelectList(db.Aviones, "Modelo", "Modelo", vuelo.Avion);
            ViewBag.Piloto = new SelectList(db.Empleados, "Nombre", "Apellido", vuelo.Piloto);
            return View(vuelo);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Editar([Bind(Include = "Piloto,Avion,Cantidad_Pasajeros")] Vuelo vuelo)
        {
            if (ModelState.IsValid)
            {
                db.Entry(vuelo).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Avion = new SelectList(db.Aviones, "Modelo", "Modelo", vuelo.Avion);
            ViewBag.Piloto = new SelectList(db.Empleados, "Nombre", "Apellido", vuelo.Piloto);
            return View(vuelo);
        }

        public ActionResult Eliminar(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Vuelo vuelo = db.Vuelos.Find(id);
            if (vuelo == null)
            {
                return HttpNotFound();
            }
            return View(vuelo);
        }

        [HttpPost, ActionName("Eliminar")]
        [ValidateAntiForgeryToken]
        public ActionResult ConfirmacionEliminar(string id)
        {
            Vuelo vuelo = db.Vuelos.Find(id);
            db.Vuelos.Remove(vuelo);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}