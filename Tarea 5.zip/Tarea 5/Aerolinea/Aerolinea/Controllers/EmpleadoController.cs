﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Aerolinea.Models;

namespace Aerolinea.Controllers
{
    public class EmpleadoController : Controller
    {
        private AeroliniaEntities db = new AeroliniaEntities();

        public ActionResult Index()
        {
            var empleados = db.Empleados.Include(e => e.Vuelo);
            return View(empleados.ToList());
        }

        public ActionResult Agregar()
        {
            ViewBag.Nombre = new SelectList(db.Vuelos, "Piloto", "Avion");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Agregar([Bind(Include = "Nombre,Apellido,Posicion")] Empleado empleado)
        {
            if (ModelState.IsValid)
            {
                db.Empleados.Add(empleado);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Nombre = new SelectList(db.Vuelos, "Piloto", "Avion", empleado.Nombre);
            return View(empleado);
        }

        public ActionResult Editar(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Empleado empleado = db.Empleados.Find(id);
            if (empleado == null)
            {
                return HttpNotFound();
            }
            ViewBag.Nombre = new SelectList(db.Vuelos, "Piloto", "Avion", empleado.Nombre);
            return View(empleado);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Editar([Bind(Include = "Nombre,Apellido,Posicion")] Empleado empleado)
        {
            if (ModelState.IsValid)
            {
                db.Entry(empleado).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Nombre = new SelectList(db.Vuelos, "Piloto", "Avion", empleado.Nombre);
            return View(empleado);
        }

        public ActionResult Eliminar(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Empleado empleado = db.Empleados.Find(id);
            if (empleado == null)
            {
                return HttpNotFound();
            }
            return View(empleado);
        }

        [HttpPost, ActionName("Eliminar")]
        [ValidateAntiForgeryToken]
        public ActionResult ConfirmacionEliminar(string id)
        {
            Empleado empleado = db.Empleados.Find(id);
            db.Empleados.Remove(empleado);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}