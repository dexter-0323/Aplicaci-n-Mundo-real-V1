﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Aerolinea.Models;

namespace Aerolinea.Controllers
{
    public class AvionController : Controller
    {
        private AeroliniaEntities db = new AeroliniaEntities();

        public ActionResult Index()
        {
            return View(db.Aviones.ToList());
        }

        public ActionResult Agregar()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Agregar([Bind(Include = "Modelo,Capacidad")] Avione avione)
        {
            if (ModelState.IsValid)
            {
                db.Aviones.Add(avione);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(avione);
        }

        public ActionResult Editar(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Avione avione = db.Aviones.Find(id);
            if (avione == null)
            {
                return HttpNotFound();
            }
            return View(avione);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Editar([Bind(Include = "Modelo,Capacidad")] Avione avione)
        {
            if (ModelState.IsValid)
            {
                db.Entry(avione).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(avione);
        }

        public ActionResult Eliminar(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Avione avione = db.Aviones.Find(id);
            if (avione == null)
            {
                return HttpNotFound();
            }
            return View(avione);
        }

        [HttpPost, ActionName("Eliminar")]
        [ValidateAntiForgeryToken]
        public ActionResult ConfirmacionEliminar(string id)
        {
            Avione avione = db.Aviones.Find(id);
            db.Aviones.Remove(avione);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}