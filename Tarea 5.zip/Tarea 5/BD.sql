create database Aerolinia

USE [Aerolinia]
GO

CREATE TABLE Aviones(
	Modelo varchar(50) Primary key,
	Capacidad int
)


CREATE TABLE Empleados(
	Nombre varchar(40) Primary key,
	Apellido varchar(40),
	Posicion varchar(40)
)


CREATE TABLE Vuelos(
	Piloto varchar(40) Primary key,
	Avion varchar(50),
	Cantidad_Pasajeros int
)

Alter table Vuelos add foreign key (Piloto) references Empleados (Nombre)
Alter table Vuelos add foreign key (Avion) references Aviones (Modelo)

SELECT * FROM Aviones
SELECT * FROM Empleados
SELECT * FROM Vuelos

drop table Aviones
drop table Empleados
drop table Vuelos